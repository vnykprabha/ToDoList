﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineToDoList.Entities.Entities
{
    public class Response
    {        
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}
